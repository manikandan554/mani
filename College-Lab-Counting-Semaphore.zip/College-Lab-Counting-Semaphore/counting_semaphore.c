#include <stdio.h>

#define MAX_STUDENTS 100

int semaphore;
int total_computers;
int allocated = 0;

void waitSemaphore(int student_id)
{
    if (semaphore > 0)
    {
        semaphore--;
        allocated++;

        printf("\nStudent %d allocated a computer.\n", student_id);
        printf("Available Computers : %d\n", semaphore);
        printf("Allocated Computers : %d\n", allocated);
    }
    else
    {
        printf("\nStudent %d must wait.\n", student_id);
        printf("No computers are currently available.\n");
    }
}

void signalSemaphore(int student_id)
{
    if (allocated > 0)
    {
        semaphore++;
        allocated--;

        printf("\nStudent %d completed the work.\n", student_id);
        printf("Computer released successfully.\n");
        printf("Available Computers : %d\n", semaphore);
        printf("Allocated Computers : %d\n", allocated);
    }
}

int main()
{
    int n, i;
    int choice;
    int active[MAX_STUDENTS] = {0};

    printf("\n================================================\n");
    printf("       COLLEGE COMPUTER LAB MANAGEMENT\n");
    printf("          COUNTING SEMAPHORE\n");
    printf("================================================\n");

    printf("\nEnter total number of computers: ");
    if (scanf("%d", &total_computers) != 1 || total_computers <= 0)
    {
        printf("Invalid number of computers!\n");
        return 1;
    }

    semaphore = total_computers;

    printf("Enter number of students: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > MAX_STUDENTS)
    {
        printf("Invalid number of students!\n");
        return 1;
    }

    printf("\nInitial Laboratory Status\n");
    printf("Total Computers     : %d\n", total_computers);
    printf("Available Computers : %d\n", semaphore);
    printf("Allocated Computers : %d\n", allocated);

    for (i = 0; i < n; i++)
    {
        printf("\n----------------------------------------------\n");
        printf("Student %d requesting computer access\n", i + 1);

        waitSemaphore(i + 1);

        if (semaphore < total_computers)
        {
            active[i] = 1;
        }
    }

    printf("\n================================================\n");
    printf("          COMPUTER RELEASE PROCESS\n");
    printf("================================================\n");

    for (i = 0; i < n; i++)
    {
        if (active[i] == 1)
        {
            printf("\nRelease computer for Student %d? (1=Yes, 0=No): ",
                   i + 1);

            if (scanf("%d", &choice) != 1)
            {
                printf("Invalid input. Computer remains allocated.\n");
                return 1;
            }

            if (choice == 1)
            {
                signalSemaphore(i + 1);
                active[i] = 0;
            }
        }
    }

    printf("\n================================================\n");
    printf("             FINAL LAB STATUS\n");
    printf("================================================\n");

    printf("Total Computers     : %d\n", total_computers);
    printf("Available Computers : %d\n", semaphore);
    printf("Allocated Computers : %d\n", allocated);

    printf("\n===============================================\n");
    printf("     LAB COMPUTER ALLOCATION COMPLETED\n");
    printf("===============================================\n");

    return 0;
}
