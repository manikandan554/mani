# College Computer Laboratory – Counting Semaphore

## Description
This project simulates computer allocation in a college computer laboratory using the counting semaphore concept in C.

A limited number of computers are shared among multiple students. The semaphore count represents the number of available computers. A student receives a computer when the count is greater than zero. When a student finishes, the computer is released and the available count is increased.

## Objectives
- Demonstrate the counting semaphore concept.
- Manage a limited number of laboratory computers.
- Allocate computers when resources are available.
- Make additional requests wait when all computers are occupied.
- Release computers after students finish their work.
- Display available and allocated computer counts.

## Algorithm
1. Start the program.
2. Read the total number of computers and number of students.
3. Initialize the semaphore to the total number of computers.
4. For each student, check whether the semaphore count is greater than zero.
5. If a computer is available, decrement the semaphore and increase the allocated count.
6. Otherwise, display that the student must wait.
7. Ask students with allocated computers whether they have completed their work.
8. When a computer is released, increment the semaphore and decrease the allocated count.
9. Display the final laboratory status.
10. Stop the program.

## Sample Input
- Total computers: 3
- Number of students: 5
- Release choice for Students 1, 2, and 3: 1 (Yes)

## Expected Output
See [output.txt](output.txt) for the complete sample output.

## Compile and Run

Compile using GCC:

```bash
gcc counting_semaphore.c -o counting_semaphore
```

Run on Windows:

```bash
counting_semaphore.exe
```

Run on Linux or macOS:

```bash
./counting_semaphore
```

## Result
The counting semaphore concept was simulated to manage access to a limited number of computers in a college laboratory. The program displays computer allocation, waiting requests, resource release, and the final number of available and allocated computers.

## Note
This is a sequential educational simulation of counting semaphore behaviour. It does not create actual concurrent student processes or use an operating-system semaphore API.
